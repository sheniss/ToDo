<?php

require "config/include.php";



$id = $database->insert('hodnoty', [
	'text' => $_POST['message'],
	'jmeno' => $_POST['jmeno'],
	'prijmeni' => $_POST['prijmeni'],
	'email' => $_POST['email']
    
]); 

if ( $id ){
	header('Location: /Zaverecny_projekt_Senkerik');
	die();
}